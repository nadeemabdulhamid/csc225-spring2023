public class EmptyListException extends RuntimeException {
    EmptyListException(String message) {
        super(message);
    }
}
