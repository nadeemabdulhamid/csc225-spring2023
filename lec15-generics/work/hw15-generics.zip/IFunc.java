
//  Function//

public interface IFunc<A, B>
{
  public B apply(A obj);
}


///  map : (A -> B) [Listof A] -> [Listof B]
